import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Brain, User, Eye, BookOpen } from 'lucide-react'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('intro')

  const sections = [
    { id: 'intro', title: 'Introducción', icon: BookOpen },
    { id: 'freud', title: 'Freud', icon: Brain },
    { id: 'lacan', title: 'Lacan', icon: User },
    { id: 'ejemplo', title: 'Ejemplo', icon: Eye }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-slate-800">
            El Concepto del Fantasma en Psicoanálisis
          </h1>
          <p className="text-slate-600 mt-2">
            Una exploración de las perspectivas de Freud y Lacan
          </p>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="text-lg">Navegación</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {sections.map((section) => {
                  const Icon = section.icon
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                        activeSection === section.id
                          ? 'bg-blue-100 text-blue-700 border border-blue-200'
                          : 'hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <Icon size={18} />
                      {section.title}
                    </button>
                  )
                })}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeSection === 'intro' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="text-blue-600" />
                    Introducción
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate max-w-none">
                  <p className="text-lg leading-relaxed">
                    El término "fantasma" en psicoanálisis es un concepto complejo y fundamental que difiere 
                    significativamente de su uso coloquial. Si bien en el lenguaje común se asocia con apariciones 
                    o imaginaciones, en el psicoanálisis se refiere a una <strong>estructura psíquica inconsciente</strong> que 
                    organiza la realidad del sujeto y su relación con el deseo.
                  </p>
                  
                  <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400 my-6">
                    <h4 className="font-semibold text-blue-800 mb-2">Concepto Clave</h4>
                    <p className="text-blue-700">
                      El fantasma no es una simple fantasía, sino una estructura fundamental que organiza 
                      la percepción de la realidad y la relación con el deseo.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === 'freud' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="text-green-600" />
                    La Perspectiva de Sigmund Freud: La Fantasía
                  </CardTitle>
                  <CardDescription>
                    El concepto freudiano de fantasía como precursor del fantasma lacaniano
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <p className="text-lg leading-relaxed mb-4">
                      Para Freud, el concepto que más se acerca al "fantasma" lacaniano es el de <strong>fantasía</strong> 
                      (<em>Phantasie</em> en alemán). Freud entendía la fantasía como una actividad psíquica que opera 
                      tanto a nivel consciente como inconsciente.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-green-800 mb-2">Fantasías Conscientes</h4>
                      <ul className="text-green-700 space-y-1">
                        <li>• Sueños diurnos</li>
                        <li>• Creación artística</li>
                        <li>• Realizaciones de deseos</li>
                      </ul>
                    </div>
                    <div className="bg-amber-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-amber-800 mb-2">Fantasías Inconscientes</h4>
                      <ul className="text-amber-700 space-y-1">
                        <li>• Origen de síntomas neuróticos</li>
                        <li>• Guiones internos</li>
                        <li>• Defensas psíquicas</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Función de la Fantasía según Freud</h4>
                    <p>
                      La fantasía freudiana es una construcción psíquica que permite al sujeto satisfacer deseos 
                      de manera imaginaria, funcionando como un refugio del principio de realidad y como un motor 
                      para la creatividad, pero también como un posible origen de patologías.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === 'lacan' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="text-purple-600" />
                    La Perspectiva de Jacques Lacan: El Fantasma Fundamental
                  </CardTitle>
                  <CardDescription>
                    La formalización estructural del concepto freudiano
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-lg leading-relaxed">
                    Lacan retoma el concepto freudiano de fantasía y lo eleva a una categoría estructural, 
                    denominándolo <strong>fantasma fundamental</strong> (<em>fantasme</em> en francés).
                  </p>

                  <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                    <h4 className="font-bold text-purple-800 mb-4 text-center text-xl">
                      Fórmula del Fantasma
                    </h4>
                    <div className="text-center mb-4">
                      <span className="text-4xl font-mono bg-white px-4 py-2 rounded border">
                        $ ◊ a
                      </span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-mono mb-2">$</div>
                        <h5 className="font-semibold text-purple-800">Sujeto Barrado</h5>
                        <p className="text-sm text-purple-700">
                          Sujeto dividido, escindido por el lenguaje y la castración
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-mono mb-2">◊</div>
                        <h5 className="font-semibold text-purple-800">Rombo/Losange</h5>
                        <p className="text-sm text-purple-700">
                          Relación de conjunción y disyunción entre sujeto y objeto
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-mono mb-2">a</div>
                        <h5 className="font-semibold text-purple-800">Objeto a</h5>
                        <p className="text-sm text-purple-700">
                          Objeto causa del deseo, falta constitutiva
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-indigo-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-indigo-800 mb-2">Función del Fantasma en Lacan</h4>
                    <p className="text-indigo-700">
                      El fantasma es el <strong>soporte del deseo</strong>. Es una especie de "guion" o "escena" 
                      inconsciente que el sujeto se construye para dar sentido a su existencia y regular su 
                      relación con el deseo del Otro.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === 'ejemplo' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="text-orange-600" />
                    Explicación Sencilla y Ejemplo
                  </CardTitle>
                  <CardDescription>
                    Un caso práctico para entender el concepto
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-400">
                    <h4 className="font-semibold text-orange-800 mb-2">Metáfora del Filtro</h4>
                    <p className="text-orange-700">
                      Imagina el fantasma como un <strong>filtro o un par de gafas invisibles</strong> a través 
                      de las cuales una persona percibe y experimenta el mundo. Este filtro determina qué ve, 
                      cómo lo interpreta y cómo reacciona ante ello.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="font-bold text-xl mb-4">Caso de Ana: "Para ser amada, debo ser perfecta"</h4>
                    
                    <div className="space-y-4">
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h5 className="font-semibold text-green-800 mb-2 flex items-center gap-2">
                          <Brain size={18} />
                          Origen (Freud)
                        </h5>
                        <p className="text-green-700">
                          Esta creencia pudo originarse en fantasías infantiles donde Ana asociaba el amor 
                          de sus padres con su buen comportamiento. La perfección se convirtió en la "clave" 
                          del amor en su mundo psíquico.
                        </p>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg">
                        <h5 className="font-semibold text-purple-800 mb-2 flex items-center gap-2">
                          <User size={18} />
                          Estructura (Lacan)
                        </h5>
                        <p className="text-purple-700 mb-2">
                          El fantasma de Ana: <span className="font-mono bg-white px-2 py-1 rounded">$ ◊ ser perfecta para el Otro</span>
                        </p>
                        <ul className="text-purple-700 space-y-1">
                          <li>• <strong>$:</strong> Ana como sujeto dividido por la angustia</li>
                          <li>• <strong>◊:</strong> Relación estructurante con la exigencia de perfección</li>
                          <li>• <strong>a:</strong> El amor del Otro como objeto causa del deseo</li>
                        </ul>
                      </div>

                      <div className="bg-red-50 p-4 rounded-lg">
                        <h5 className="font-semibold text-red-800 mb-2">Manifestaciones en la vida diaria</h5>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <h6 className="font-medium text-red-700 mb-1">En el trabajo:</h6>
                            <p className="text-sm text-red-600">
                              Se esfuerza excesivamente, los errores generan angustia desproporcionada
                            </p>
                          </div>
                          <div>
                            <h6 className="font-medium text-red-700 mb-1">En relaciones:</h6>
                            <p className="text-sm text-red-600">
                              Dificultad para decir "no", teme el rechazo o la desaprobación
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Conclusión del Ejemplo</h4>
                    <p className="text-blue-700">
                      El fantasma de Ana organiza su percepción de la realidad y sus reacciones emocionales. 
                      Aunque genera sufrimiento, también proporciona estructura y funciona como defensa 
                      contra la angustia. El análisis psicoanalítico buscaría desentrañar este fantasma 
                      para construir relaciones más saludables.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t border-slate-200">
          <div className="text-center text-slate-600">
            <p className="mb-2">
              Basado en investigación psicoanalítica sobre el concepto del fantasma
            </p>
            <div className="flex justify-center gap-2 flex-wrap">
              <Badge variant="outline">Psicoanálisis</Badge>
              <Badge variant="outline">Freud</Badge>
              <Badge variant="outline">Lacan</Badge>
              <Badge variant="outline">Fantasma Fundamental</Badge>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}

export default App

